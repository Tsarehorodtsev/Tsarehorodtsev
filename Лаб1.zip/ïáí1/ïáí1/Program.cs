﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаб1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            Console.WriteLine("Hello Debug!");
           /* Console.WriteLine("Hello Read!");
            Console.ReadLine(); */
        }
    }
}
